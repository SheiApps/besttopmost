export { default } from "./ShopLogoWithData";
