export { default } from "./ProfileImageWithData";
